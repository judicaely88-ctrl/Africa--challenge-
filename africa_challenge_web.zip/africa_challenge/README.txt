AFRICA CHALLENGE — VERSION WEB GRATUITE

Fichier principal : index.html

TESTER SUR UN ORDINATEUR
1. Décompressez le ZIP.
2. Ouvrez index.html dans Chrome, Firefox ou Edge.

PUBLIER GRATUITEMENT SUR LE WEB (méthode simple : GitHub Pages)
1. Créez un compte gratuit sur https://github.com/
2. Créez un nouveau dépôt public nommé africa-challenge.
3. Téléversez index.html à la racine du dépôt (Add file > Upload files).
4. Dans Settings > Pages, choisissez Deploy from a branch, puis la branche main et le dossier /(root).
5. Enregistrez et attendez la publication. GitHub affichera le lien public de votre site.

À SAVOIR
- Ce prototype fonctionne sans serveur, sans compte joueur et sans base de données.
- Les scores ne sont pas conservés entre les sessions.
- Le classement en ligne, les comptes, les publicités et les paiements ne sont pas encore intégrés.
- Le jeu ne distribue pas d'argent réel.
- Avant de publier, relisez et vérifiez les questions/réponses.
